How to run project
___________________

1) open up project in IDE.
2) Go to CheckerBoard.Java.
3) Run this java file.
4) Move Red Pieces by clicking on them and clicking on the position to move them.